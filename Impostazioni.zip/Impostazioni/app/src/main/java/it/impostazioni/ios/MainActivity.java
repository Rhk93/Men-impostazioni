package it.impostazioni.ios;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private Voci.Voce radice;
    private final ArrayDeque<Voci.Voce> pila = new ArrayDeque<>();
    private ScrollView scorri;
    private LinearLayout colonna, corpo, barra;
    private TextView titoloBarra, indietro;
    private String ricerca = "";
    private int insetSu, insetGiu;
    private boolean scuro, chiesto;

    private int cSfondo, cScheda, cTesto, cTesto2, cSep, cBlu, cVerde, cFreccia, cCampo, cPremuto, cGrigioSw, cTraccia;

    // ================= Avvio =================

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        radice = Voci.crea();
        pila.push(radice);
        costruisci();
    }

    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        costruisci();
    }

    @Override
    protected void onResume() {
        super.onResume();
        chiesto = false;
        if (scorri != null) {
            final int y = scorri.getScrollY();
            mostra(false);
            scorri.post(() -> scorri.scrollTo(0, y));
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (pila.size() > 1) {
            pila.pop();
            mostra(true);
        } else {
            super.onBackPressed();
        }
    }

    private void colori() {
        scuro = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        if (scuro) {
            cSfondo = 0xFF000000; cScheda = 0xFF1C1C1E; cTesto = 0xFFFFFFFF; cTesto2 = 0xFF8D8D93;
            cSep = 0xFF38383A; cBlu = 0xFF0A84FF; cVerde = 0xFF30D158; cFreccia = 0xFF5A5A5F;
            cCampo = 0xFF1C1C1E; cPremuto = 0xFF3A3A3C; cGrigioSw = 0xFF39393D; cTraccia = 0xFF3A3A3C;
        } else {
            cSfondo = 0xFFF2F2F7; cScheda = 0xFFFFFFFF; cTesto = 0xFF000000; cTesto2 = 0xFF8A8A8E;
            cSep = 0xFFC6C6C8; cBlu = 0xFF007AFF; cVerde = 0xFF34C759; cFreccia = 0xFFC4C4C7;
            cCampo = 0xFFE3E3E8; cPremuto = 0xFFD1D1D6; cGrigioSw = 0xFFE9E9EB; cTraccia = 0xFFE5E5EA;
        }
    }

    private void costruisci() {
        colori();
        getWindow().setDecorFitsSystemWindows(false);
        getWindow().setBackgroundDrawable(new ColorDrawable(cSfondo));

        FrameLayout base = new FrameLayout(this);
        base.setBackgroundColor(cSfondo);

        scorri = new ScrollView(this);
        scorri.setClipToPadding(false);
        scorri.setVerticalScrollBarEnabled(false);
        colonna = new LinearLayout(this);
        colonna.setOrientation(LinearLayout.VERTICAL);
        colonna.setFocusableInTouchMode(true);
        scorri.addView(colonna, new FrameLayout.LayoutParams(MATCH, WRAP));
        base.addView(scorri, new FrameLayout.LayoutParams(MATCH, MATCH));

        // Barra in alto "vetro"
        barra = new LinearLayout(this);
        barra.setOrientation(LinearLayout.HORIZONTAL);
        barra.setGravity(Gravity.CENTER_VERTICAL);
        barra.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{alfa(cSfondo, 0xF5), alfa(cSfondo, 0xD8), alfa(cSfondo, 0x00)}));

        indietro = new TextView(this);
        indietro.setText("‹");
        indietro.setTextSize(30);
        indietro.setTextColor(cTesto);
        indietro.setGravity(Gravity.CENTER);
        indietro.setPadding(0, 0, dp(2), dp(4));
        GradientDrawable vetro = new GradientDrawable();
        vetro.setShape(GradientDrawable.OVAL);
        vetro.setColor(alfa(cScheda, 0xE6));
        vetro.setStroke(dp(1), scuro ? 0x33FFFFFF : 0xB3FFFFFF);
        indietro.setBackground(vetro);
        indietro.setElevation(dp(3));
        indietro.setOnClickListener(v -> onBackPressed());
        barra.addView(indietro, new LinearLayout.LayoutParams(dp(44), dp(44)));

        titoloBarra = new TextView(this);
        titoloBarra.setTextSize(17);
        titoloBarra.setTypeface(Typeface.DEFAULT_BOLD);
        titoloBarra.setTextColor(cTesto);
        titoloBarra.setGravity(Gravity.CENTER);
        titoloBarra.setSingleLine(true);
        titoloBarra.setEllipsize(TextUtils.TruncateAt.END);
        barra.addView(titoloBarra, new LinearLayout.LayoutParams(0, WRAP, 1f));
        barra.addView(new View(this), new LinearLayout.LayoutParams(dp(44), dp(44)));

        base.addView(barra, new FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP));

        base.setOnApplyWindowInsetsListener((v, ins) -> {
            Insets s = ins.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
            Insets t = ins.getInsets(WindowInsets.Type.ime());
            insetSu = s.top;
            insetGiu = Math.max(s.bottom, t.bottom);
            spazi();
            return WindowInsets.CONSUMED;
        });

        scorri.setOnScrollChangeListener((v, x, y, ox, oy) -> {
            if (pila.size() == 1) {
                float a = (y - dp(20)) / (float) dp(30);
                titoloBarra.setAlpha(Math.max(0f, Math.min(1f, a)));
            }
        });

        setContentView(base);
        WindowInsetsController wc = getWindow().getInsetsController();
        if (wc != null) {
            int chiaro = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                    | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
            wc.setSystemBarsAppearance(scuro ? 0 : chiaro, chiaro);
        }
        spazi();
        mostra(true);
    }

    private void spazi() {
        barra.setPadding(dp(12), insetSu + dp(6), dp(12), dp(12));
        colonna.setPadding(dp(16), insetSu + dp(62), dp(16), insetGiu + dp(30));
    }

    // ================= Pagine =================

    private void mostra(boolean inCima) {
        Voci.Voce cur = pila.peek();
        boolean home = pila.size() == 1;
        colonna.removeAllViews();
        indietro.setVisibility(home ? View.INVISIBLE : View.VISIBLE);
        titoloBarra.setText(home ? "Impostazioni" : cur.titolo);
        titoloBarra.setAlpha(home ? 0f : 1f);

        if (home) {
            TextView grande = testo("Impostazioni", 34, cTesto);
            grande.setTypeface(Typeface.DEFAULT_BOLD);
            grande.setPadding(dp(4), 0, 0, dp(10));
            colonna.addView(grande);

            EditText campo = new EditText(this);
            campo.setHint("⌕  Cerca");
            campo.setHintTextColor(cTesto2);
            campo.setTextColor(cTesto);
            campo.setTextSize(17);
            campo.setSingleLine(true);
            campo.setGravity(Gravity.CENTER_VERTICAL);
            campo.setPadding(dp(14), 0, dp(14), 0);
            campo.setBackground(sfondoArrotondato(cCampo, dp(20)));
            campo.setText(ricerca);
            campo.setSelection(ricerca.length());
            campo.addTextChangedListener(new TextWatcher() {
                public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
                public void onTextChanged(CharSequence s, int a, int b, int c) { }
                public void afterTextChanged(Editable s) {
                    ricerca = s.toString();
                    riempiHome();
                }
            });
            LinearLayout.LayoutParams pc = new LinearLayout.LayoutParams(MATCH, dp(42));
            pc.bottomMargin = dp(22);
            colonna.addView(campo, pc);

            corpo = new LinearLayout(this);
            corpo.setOrientation(LinearLayout.VERTICAL);
            colonna.addView(corpo, new LinearLayout.LayoutParams(MATCH, WRAP));
            riempiHome();
            colonna.requestFocus();
        } else {
            corpo = colonna;
            if (cur.tipo == Voci.SCELTA) {
                paginaScelta(cur);
            } else {
                for (Voci.Gruppo gr : cur.gruppi) gruppo(gr.intestazione, gr.voci, false);
                rigaSamsung(cur);
            }
        }
        if (inCima) scorri.post(() -> scorri.scrollTo(0, 0));
    }

    private void riempiHome() {
        corpo.removeAllViews();
        String q = ricerca.trim().toLowerCase(Locale.ITALIAN);
        if (q.isEmpty()) {
            for (Voci.Gruppo gr : radice.gruppi) gruppo(gr.intestazione, gr.voci, false);
            TextView c = testo("Copyright © Ignazio Paolicelli", 12, cTesto2);
            c.setGravity(Gravity.CENTER);
            c.setPadding(0, dp(4), 0, dp(10));
            corpo.addView(c, new LinearLayout.LayoutParams(MATCH, WRAP));
            return;
        }
        List<Voci.Voce> tutte = new ArrayList<>();
        raccogli(radice, tutte);
        List<Voci.Voce> trovate = new ArrayList<>();
        for (Voci.Voce v : tutte) {
            if (v.titolo.toLowerCase(Locale.ITALIAN).contains(q)) trovate.add(v);
            if (trovate.size() >= 100) break;
        }
        if (trovate.isEmpty()) {
            TextView n = testo("Nessun risultato per «" + ricerca.trim() + "»", 17, cTesto2);
            n.setGravity(Gravity.CENTER);
            n.setPadding(0, dp(40), 0, 0);
            corpo.addView(n, new LinearLayout.LayoutParams(MATCH, WRAP));
        } else {
            gruppo(null, trovate, true);
        }
    }

    private void raccogli(Voci.Voce v, List<Voci.Voce> out) {
        for (Voci.Gruppo gr : v.gruppi)
            for (Voci.Voce f : gr.voci) {
                out.add(f);
                raccogli(f, out);
            }
    }

    private void gruppo(String intestazione, List<Voci.Voce> voci, boolean conPercorso) {
        if (intestazione != null) {
            TextView h = testo(intestazione, 13, cTesto2);
            h.setPadding(dp(16), 0, dp(16), dp(7));
            corpo.addView(h);
        }
        LinearLayout scheda = scheda();
        for (int i = 0; i < voci.size(); i++) {
            Voci.Voce v = voci.get(i);
            if (i > 0) scheda.addView(separatore(v.icona != null ? dp(60) : dp(16)));
            String sotto = conPercorso ? v.percorso() : v.sotto;
            scheda.addView(riga(v, sotto));
        }
        aggiungiScheda(scheda);
    }

    private void rigaSamsung(Voci.Voce cur) {
        LinearLayout scheda = scheda();
        TextView t = testo("Apri «" + cur.titolo + "» nelle Impostazioni Samsung", 17, cBlu);
        t.setMinHeight(dp(52));
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(dp(16), dp(8), dp(16), dp(8));
        t.setBackground(premibile());
        t.setOnClickListener(v -> apri(cur));
        scheda.addView(t, new LinearLayout.LayoutParams(MATCH, WRAP));
        aggiungiScheda(scheda);
    }

    private void paginaScelta(Voci.Voce v) {
        int attuale = leggiScelta(v.id);
        LinearLayout scheda = scheda();
        for (int i = 0; i < v.opzioni.length; i++) {
            final int valore = v.valori[i];
            if (i > 0) scheda.addView(separatore(dp(16)));
            LinearLayout r = rigaBase(false);
            r.addView(testo(v.opzioni[i], 17, cTesto), new LinearLayout.LayoutParams(0, WRAP, 1f));
            TextView spunta = testo(valore == attuale ? "✓" : "", 19, cBlu);
            spunta.setTypeface(Typeface.DEFAULT_BOLD);
            r.addView(spunta);
            r.setBackground(premibile());
            r.setOnClickListener(x -> {
                impostaScelta(v.id, valore);
                mostra(false);
            });
            scheda.addView(r);
        }
        aggiungiScheda(scheda);
    }

    // ================= Righe =================

    private View riga(Voci.Voce v, String sotto) {
        if (v.tipo == Voci.CURSORE) return rigaCursore(v);
        boolean conSotto = sotto != null && !sotto.isEmpty();
        boolean account = "👤".equals(v.icona);
        LinearLayout r = rigaBase(conSotto);

        if (v.icona != null) {
            TextView ic = new TextView(this);
            ic.setText(v.icona);
            ic.setGravity(Gravity.CENTER);
            ic.setTextColor(Color.WHITE);
            ic.setTextSize(account ? 30 : 16);
            ic.setTypeface(Typeface.DEFAULT_BOLD);
            ic.setIncludeFontPadding(false);
            GradientDrawable d = new GradientDrawable();
            d.setColor(v.colore);
            if (account) d.setShape(GradientDrawable.OVAL);
            else d.setCornerRadius(dp(8));
            ic.setBackground(d);
            int s = dp(account ? 60 : 30);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(s, s);
            p.rightMargin = dp(14);
            r.addView(ic, p);
        }

        LinearLayout testi = new LinearLayout(this);
        testi.setOrientation(LinearLayout.VERTICAL);
        TextView t = testo(v.titolo, account ? 20 : 17, cTesto);
        if (account) t.setTypeface(Typeface.DEFAULT_BOLD);
        testi.addView(t);
        if (conSotto) {
            TextView s = testo(sotto, account ? 14 : 13, cTesto2);
            s.setSingleLine(true);
            s.setEllipsize(TextUtils.TruncateAt.END);
            testi.addView(s);
        }
        r.addView(testi, new LinearLayout.LayoutParams(0, WRAP, 1f));

        switch (v.tipo) {
            case Voci.INTERRUTTORE: {
                Interruttore sw = new Interruttore(this, cVerde, cGrigioSw);
                sw.imposta(leggiInterruttore(v.id), false);
                View.OnClickListener cambia = x -> {
                    impostaInterruttore(v.id, !sw.acceso);
                    sw.imposta(leggiInterruttore(v.id), true);
                };
                sw.setOnClickListener(cambia);
                r.setOnClickListener(cambia);
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(51), dp(31));
                p.leftMargin = dp(8);
                r.addView(sw, p);
                break;
            }
            case Voci.SCELTA: {
                r.addView(testo(testoScelta(v), 17, cTesto2));
                r.addView(freccia());
                r.setBackground(premibile());
                r.setOnClickListener(x -> apriPagina(v));
                break;
            }
            default: {
                r.addView(freccia());
                r.setBackground(premibile());
                r.setOnClickListener(x -> {
                    if (v.tipo == Voci.MENU) apriPagina(v);
                    else apri(v);
                });
            }
        }
        return r;
    }

    private View rigaCursore(Voci.Voce v) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(dp(16), dp(10), dp(16), dp(8));
        r.addView(testo(v.titolo, 15, cTesto));

        SeekBar sb = new SeekBar(this);
        int[] st = leggiCursore(v.id);
        sb.setMax(Math.max(1, st[1]));
        sb.setProgress(st[0]);
        sb.setProgressTintList(ColorStateList.valueOf(cBlu));
        sb.setProgressBackgroundTintList(ColorStateList.valueOf(cTraccia));
        sb.setSplitTrack(false);
        sb.setMinHeight(dp(4));
        sb.setMaxHeight(dp(4));
        GradientDrawable pallino = new GradientDrawable();
        pallino.setShape(GradientDrawable.OVAL);
        pallino.setColor(Color.WHITE);
        pallino.setStroke(Math.max(1, dp(0.7f)), 0x33000000);
        pallino.setSize(dp(26), dp(26));
        sb.setThumb(pallino);
        sb.setPadding(dp(14), dp(10), dp(14), dp(10));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean utente) {
                if (utente) impostaCursore(v.id, p);
            }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) {
                int[] n = leggiCursore(v.id);
                s.setProgress(n[0]);
            }
        });
        r.addView(sb, new LinearLayout.LayoutParams(MATCH, WRAP));
        return r;
    }

    private LinearLayout rigaBase(boolean alta) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setMinimumHeight(dp(alta ? 62 : 52));
        r.setPadding(dp(16), dp(8), dp(14), dp(8));
        return r;
    }

    private TextView freccia() {
        TextView f = testo("›", 26, cFreccia);
        f.setPadding(dp(8), 0, 0, dp(3));
        return f;
    }

    private LinearLayout scheda() {
        LinearLayout s = new LinearLayout(this);
        s.setOrientation(LinearLayout.VERTICAL);
        s.setBackground(sfondoArrotondato(cScheda, dp(26)));
        s.setClipToOutline(true);
        return s;
    }

    private void aggiungiScheda(LinearLayout s) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(MATCH, WRAP);
        p.bottomMargin = dp(24);
        corpo.addView(s, p);
    }

    private View separatore(int rientro) {
        View sep = new View(this);
        sep.setBackgroundColor(cSep);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(MATCH, Math.max(1, dp(0.5f)));
        p.leftMargin = rientro;
        sep.setLayoutParams(p);
        return sep;
    }

    private void apriPagina(Voci.Voce v) {
        pila.push(v);
        mostra(true);
    }

    // ================= Apertura pagine Samsung =================

    private void apri(Voci.Voce v) {
        for (String az : v.azioniEffettive()) {
            if (avvia(az)) {
                if (Voci.PRINCIPALE.equals(az) && v.padre != null) suggerisci(v.titolo);
                return;
            }
        }
        avvia(Voci.PRINCIPALE);
        suggerisci(v.titolo);
    }

    private void suggerisci(String titolo) {
        try {
            ClipboardManager cm = getSystemService(ClipboardManager.class);
            cm.setPrimaryClip(ClipData.newPlainText("voce", titolo));
        } catch (Exception ignored) { }
        avviso("Cerca «" + titolo + "» in alto (nome già copiato)");
    }

    private boolean avvia(String az) {
        try {
            Intent i;
            if (az.startsWith("app:")) {
                i = getPackageManager().getLaunchIntentForPackage(az.substring(4));
                if (i == null) return false;
            } else if (az.contains("/")) {
                i = new Intent();
                i.setComponent(ComponentName.unflattenFromString(az));
            } else {
                i = new Intent(az);
            }
            startActivity(i);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // ================= Comandi diretti =================

    private boolean puoScrivere() {
        if (Settings.System.canWrite(this)) return true;
        if (!chiesto) {
            chiesto = true;
            avviso("Attiva «Modifica impostazioni di sistema», poi torna indietro");
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception ignored) { }
        }
        return false;
    }

    private boolean puoNonDisturbare() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm.isNotificationPolicyAccessGranted()) return true;
        if (!chiesto) {
            chiesto = true;
            avviso("Consenti l'accesso a «Non disturbare», poi torna indietro");
            try {
                startActivity(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));
            } catch (Exception ignored) { }
        }
        return false;
    }

    private int sys(String k, int def) {
        return Settings.System.getInt(getContentResolver(), k, def);
    }

    private void scriviSys(String k, int val) {
        if (!puoScrivere()) return;
        try {
            Settings.System.putInt(getContentResolver(), k, val);
        } catch (Exception e) {
            avviso("Questa impostazione si può cambiare solo dalle Impostazioni Samsung");
        }
    }

    private String chiaveSys(String id) {
        switch (id) {
            case "luminosita_auto": return Settings.System.SCREEN_BRIGHTNESS_MODE;
            case "rotazione": return Settings.System.ACCELEROMETER_ROTATION;
            case "suoni_tocco": return Settings.System.SOUND_EFFECTS_ENABLED;
            case "vibrazione_tocco": return Settings.System.HAPTIC_FEEDBACK_ENABLED;
            case "toni_tastiera": return Settings.System.DTMF_TONE_WHEN_DIALING;
            default: return null;
        }
    }

    private boolean leggiInterruttore(String id) {
        if ("non_disturbare".equals(id)) {
            int f = getSystemService(NotificationManager.class).getCurrentInterruptionFilter();
            return f != NotificationManager.INTERRUPTION_FILTER_ALL
                    && f != NotificationManager.INTERRUPTION_FILTER_UNKNOWN;
        }
        String k = chiaveSys(id);
        return k != null && sys(k, 0) == 1;
    }

    private void impostaInterruttore(String id, boolean on) {
        if ("non_disturbare".equals(id)) {
            if (puoNonDisturbare()) {
                getSystemService(NotificationManager.class).setInterruptionFilter(on
                        ? NotificationManager.INTERRUPTION_FILTER_PRIORITY
                        : NotificationManager.INTERRUPTION_FILTER_ALL);
            }
            return;
        }
        String k = chiaveSys(id);
        if (k != null) scriviSys(k, on ? 1 : 0);
    }

    private int flusso(String id) {
        switch (id) {
            case "vol_suoneria": return AudioManager.STREAM_RING;
            case "vol_notifiche": return AudioManager.STREAM_NOTIFICATION;
            case "vol_media": return AudioManager.STREAM_MUSIC;
            case "vol_sistema": return AudioManager.STREAM_SYSTEM;
            case "vol_sveglia": return AudioManager.STREAM_ALARM;
            default: return -1;
        }
    }

    private int[] leggiCursore(String id) {
        if ("luminosita".equals(id)) return new int[]{sys(Settings.System.SCREEN_BRIGHTNESS, 128), 255};
        int f = flusso(id);
        if (f < 0) return new int[]{0, 1};
        AudioManager am = getSystemService(AudioManager.class);
        return new int[]{am.getStreamVolume(f), am.getStreamMaxVolume(f)};
    }

    private void impostaCursore(String id, int val) {
        if ("luminosita".equals(id)) {
            scriviSys(Settings.System.SCREEN_BRIGHTNESS, val);
            return;
        }
        int f = flusso(id);
        if (f < 0) return;
        try {
            getSystemService(AudioManager.class).setStreamVolume(f, val, 0);
        } catch (SecurityException e) {
            puoNonDisturbare();
        }
    }

    private int leggiScelta(String id) {
        if ("timeout".equals(id)) return sys(Settings.System.SCREEN_OFF_TIMEOUT, 30000);
        if ("modalita_suono".equals(id)) return getSystemService(AudioManager.class).getRingerMode();
        return -1;
    }

    private void impostaScelta(String id, int val) {
        if ("timeout".equals(id)) {
            scriviSys(Settings.System.SCREEN_OFF_TIMEOUT, val);
        } else if ("modalita_suono".equals(id)) {
            try {
                getSystemService(AudioManager.class).setRingerMode(val);
            } catch (SecurityException e) {
                puoNonDisturbare();
            }
        }
    }

    private String testoScelta(Voci.Voce v) {
        int att = leggiScelta(v.id);
        for (int i = 0; i < v.valori.length; i++) if (v.valori[i] == att) return v.opzioni[i];
        return "";
    }

    // ================= Utilità =================

    private TextView testo(String s, float sp, int colore) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(colore);
        return t;
    }

    private GradientDrawable sfondoArrotondato(int colore, int raggio) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(colore);
        d.setCornerRadius(raggio);
        return d;
    }

    private RippleDrawable premibile() {
        return new RippleDrawable(ColorStateList.valueOf(cPremuto), null, new ColorDrawable(Color.WHITE));
    }

    private void avviso(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private static int alfa(int colore, int a) {
        return (colore & 0x00FFFFFF) | (a << 24);
    }

    /** Interruttore stile iPhone. */
    static class Interruttore extends View {
        boolean acceso;
        float pos;
        final int verde, grigio;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final RectF r = new RectF();

        Interruttore(Context c, int verde, int grigio) {
            super(c);
            this.verde = verde;
            this.grigio = grigio;
            setLayerType(LAYER_TYPE_SOFTWARE, null);
        }

        void imposta(boolean on, boolean anima) {
            acceso = on;
            float fine = on ? 1f : 0f;
            if (!anima) {
                pos = fine;
                invalidate();
                return;
            }
            ValueAnimator a = ValueAnimator.ofFloat(pos, fine);
            a.setDuration(220);
            a.addUpdateListener(x -> {
                pos = (float) x.getAnimatedValue();
                invalidate();
            });
            a.start();
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            p.clearShadowLayer();
            p.setColor(mescola(grigio, verde, pos));
            r.set(0, 0, w, h);
            c.drawRoundRect(r, h / 2f, h / 2f, p);
            float m = h * 0.07f;
            float raggio = h / 2f - m;
            float cx = m + raggio + (w - 2 * m - 2 * raggio) * pos;
            p.setColor(Color.WHITE);
            p.setShadowLayer(h * 0.08f, 0, h * 0.04f, 0x40000000);
            c.drawCircle(cx, h / 2f, raggio, p);
        }

        static int mescola(int a, int b, float t) {
            int ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
            int br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
            return 0xFF000000
                    | (Math.round(ar + (br - ar) * t) << 16)
                    | (Math.round(ag + (bg - ag) * t) << 8)
                    | Math.round(ab + (bb - ab) * t);
        }
    }
}
