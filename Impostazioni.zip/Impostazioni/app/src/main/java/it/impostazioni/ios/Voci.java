package it.impostazioni.ios;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Tutte le voci delle Impostazioni (struttura One UI 8.5). */
public class Voci {

    public static final int MENU = 0, APRI = 1, INTERRUTTORE = 2, CURSORE = 3, SCELTA = 4;

    public static class Voce {
        public int tipo;
        public String titolo, sotto, icona, id;
        public int colore;
        public String[] azioni = new String[0];
        public List<Gruppo> gruppi = new ArrayList<>();
        public String[] opzioni;
        public int[] valori;
        public Voce padre;

        /** Azioni da provare: le proprie, altrimenti quelle del menu che la contiene. */
        public String[] azioniEffettive() {
            Voce v = this;
            while (v != null) {
                if (v.azioni.length > 0) return v.azioni;
                v = v.padre;
            }
            return new String[0];
        }

        public String percorso() {
            StringBuilder sb = new StringBuilder();
            Voce v = padre;
            while (v != null && v.padre != null) {
                sb.insert(0, sb.length() > 0 ? v.titolo + " › " : v.titolo);
                v = v.padre;
            }
            return sb.toString();
        }
    }

    public static class Gruppo {
        public String intestazione;
        public List<Voce> voci = new ArrayList<>();
    }

    // ---------- Azioni ----------
    static final String S = "android.settings.";
    static final String WIFI = S + "WIFI_SETTINGS", BT = S + "BLUETOOTH_SETTINGS", NFC = S + "NFC_SETTINGS",
            NFCPAY = S + "NFC_PAYMENT_SETTINGS", AEREO = S + "AIRPLANE_MODE_SETTINGS", WIRELESS = S + "WIRELESS_SETTINGS",
            SIM = S + "MANAGE_ALL_SIM_PROFILES_SETTINGS", RETE = S + "DATA_ROAMING_SETTINGS", OPERATORE = S + "NETWORK_OPERATOR_SETTINGS",
            DATI = S + "DATA_USAGE_SETTINGS", TETHER = S + "TETHER_SETTINGS", VPN = S + "VPN_SETTINGS",
            STAMPA = S + "ACTION_PRINT_SETTINGS", CAST = S + "CAST_SETTINGS", SUONI = S + "SOUND_SETTINGS",
            NOTIF = S + "ALL_APPS_NOTIFICATION_SETTINGS", NOTIF2 = S + "NOTIFICATION_SETTINGS", ZEN = S + "ZEN_MODE_SETTINGS",
            STORIA_NOTIF = S + "NOTIFICATION_HISTORY", ASSIST_NOTIF = S + "NOTIFICATION_ASSISTANT_SETTINGS",
            LISTENER = S + "ACTION_NOTIFICATION_LISTENER_SETTINGS", SCHERMO = S + "DISPLAY_SETTINGS",
            NOTTE = S + "NIGHT_DISPLAY_SETTINGS", SCURO = S + "DARK_THEME_SETTINGS", SALVASCHERMO = S + "DREAM_SETTINGS",
            TESTO = S + "TEXT_READING_SETTINGS", BATTERIA = "android.intent.action.POWER_USAGE_SUMMARY",
            RISPARMIO = S + "BATTERY_SAVER_SETTINGS", OTTIM = S + "IGNORE_BATTERY_OPTIMIZATION_SETTINGS",
            SFONDO = "android.intent.action.SET_WALLPAPER", SICUREZZA = S + "SECURITY_SETTINGS",
            BIOMETRIA = S + "BIOMETRIC_ENROLL", BLOCCO = "android.app.action.SET_NEW_PASSWORD",
            PRIVACY = S + "PRIVACY_SETTINGS", PERMESSI = "android.intent.action.MANAGE_PERMISSIONS",
            USO_PERMESSI = "android.intent.action.REVIEW_PERMISSION_USAGE", POSIZIONE = S + "LOCATION_SOURCE_SETTINGS",
            EMERGENZA = S + "EDIT_EMERGENCY_INFO", ACCOUNT = S + "SYNC_SETTINGS", ADD_ACCOUNT = S + "ADD_ACCOUNT_SETTINGS",
            PREDEF = S + "MANAGE_DEFAULT_APPS_SETTINGS", TUTTE_APP = S + "MANAGE_ALL_APPLICATIONS_SETTINGS",
            APP = S + "APPLICATION_SETTINGS", SOPRA = S + "action.MANAGE_OVERLAY_PERMISSION",
            SCRIVI = S + "action.MANAGE_WRITE_SETTINGS", SCONOSCIUTE = S + "MANAGE_UNKNOWN_APP_SOURCES",
            UTILIZZO = S + "USAGE_ACCESS_SETTINGS", ACCESSO_ZEN = S + "NOTIFICATION_POLICY_ACCESS_SETTINGS",
            SVEGLIE = S + "MANAGE_APP_ALL_FILES_ACCESS_PERMISSION", FILE_TUTTI = S + "MANAGE_ALL_FILES_ACCESS_PERMISSION",
            LINGUA = S + "LOCALE_SETTINGS", TASTIERE = S + "INPUT_METHOD_SETTINGS", TASTIERA_FISICA = S + "HARD_KEYBOARD_SETTINGS",
            DIZIONARIO = S + "USER_DICTIONARY_SETTINGS", DATA = S + "DATE_SETTINGS", VOCE_TTS = "com.android.settings.TTS_SETTINGS",
            ACCESSIBILITA = S + "ACCESSIBILITY_SETTINGS", SOTTOTITOLI = S + "CAPTIONING_SETTINGS",
            INFO = S + "DEVICE_INFO_SETTINGS", ARCHIVIO = S + "INTERNAL_STORAGE_SETTINGS", SVILUPPO = S + "APPLICATION_DEVELOPMENT_SETTINGS",
            AGGIORNA = S + "SYSTEM_UPDATE_SETTINGS", HOME = S + "HOME_SETTINGS", WEBVIEW = S + "WEBVIEW_SETTINGS",
            AUTOFILL = S + "REQUEST_SET_AUTOFILL_SERVICE", CREDENZIALI = S + "CREDENTIAL_PROVIDER",
            SICUREZZA_CENTRO = S + "SAFETY_CENTER", LEGALE = S + "LICENSE", WIFI_IP = S + "WIFI_IP_SETTINGS",
            AMMINISTRATORI = S + "DEVICE_ADMIN_SETTINGS", PRINCIPALE = S + "SETTINGS";

    static final String DEVICE_CARE = "com.samsung.android.lool/com.samsung.android.sm.score.ui.ScoreBoardActivity";
    static final String GOOGLE = "com.google.android.gms/com.google.android.gms.app.settings.GoogleSettingsLink";
    static final String GOOGLE2 = "com.google.android.gms/com.google.android.gms.app.settings.GoogleSettingsActivity";

    // ---------- Costruttori brevi ----------
    static String[] az(String... a) { return a; }

    static Gruppo g(Voce... v) { return gt(null, v); }

    static Gruppo gt(String intestazione, Voce... v) {
        Gruppo gr = new Gruppo();
        gr.intestazione = intestazione;
        gr.voci.addAll(Arrays.asList(v));
        return gr;
    }

    /** Menu principale con icona. */
    static Voce M(String icona, int colore, String titolo, String sotto, String[] azioni, Gruppo... gruppi) {
        Voce v = m(titolo, azioni, gruppi);
        v.icona = icona; v.colore = colore; v.sotto = sotto;
        return v;
    }

    /** Sottomenu. */
    static Voce m(String titolo, String[] azioni, Gruppo... gruppi) {
        Voce v = new Voce();
        v.tipo = MENU; v.titolo = titolo; v.azioni = azioni;
        v.gruppi.addAll(Arrays.asList(gruppi));
        return v;
    }

    /** Voce principale con icona che apre direttamente. */
    static Voce L(String icona, int colore, String titolo, String sotto, String... azioni) {
        Voce v = a(titolo, azioni);
        v.icona = icona; v.colore = colore; v.sotto = sotto;
        return v;
    }

    /** Voce che apre la pagina Samsung (se senza azioni usa quelle del menu). */
    static Voce a(String titolo, String... azioni) {
        Voce v = new Voce();
        v.tipo = APRI; v.titolo = titolo; v.azioni = azioni;
        return v;
    }

    static Voce interruttore(String titolo, String id) {
        Voce v = new Voce(); v.tipo = INTERRUTTORE; v.titolo = titolo; v.id = id; return v;
    }

    static Voce cursore(String titolo, String id) {
        Voce v = new Voce(); v.tipo = CURSORE; v.titolo = titolo; v.id = id; return v;
    }

    static Voce scelta(String titolo, String id, String[] opzioni, int[] valori) {
        Voce v = new Voce(); v.tipo = SCELTA; v.titolo = titolo; v.id = id;
        v.opzioni = opzioni; v.valori = valori;
        return v;
    }

    static final String T = "︎";

    // ---------- Albero ----------
    public static Voce crea() {
        Voce radice = m("Impostazioni", az(PRINCIPALE),

            g(L("👤", 0xFF8E8E93, "Account Samsung", "Accedi o gestisci il tuo account",
                    "app:com.osp.app.signin", ACCOUNT)),

            g(
                M("⇅" + T, 0xFF007AFF, "Connessioni", "Wi-Fi • Bluetooth • Gestione SIM", az(WIRELESS),
                    g(a("Wi-Fi", WIFI), a("Bluetooth", BT)),
                    g(m("NFC e pagamenti contactless", az(NFC),
                            g(a("NFC e pagamenti contactless", NFC)),
                            g(a("Pagamenti contactless", NFCPAY), a("Altre impostazioni NFC", NFC))),
                      a("Ultra-Wideband (UWB)", WIRELESS)),
                    g(a("Modalità aereo", AEREO)),
                    g(a("Gestione SIM", SIM, OPERATORE, WIRELESS),
                      m("Reti mobili", az(RETE, OPERATORE, WIRELESS),
                            g(a("Roaming dati"), a("Modalità rete"), a("Nomi punti di accesso (APN)"),
                              a("Operatori di rete", OPERATORE), a("Chiamate Wi-Fi"), a("Chiamate VoLTE"))),
                      m("Utilizzo dati", az(DATI, WIRELESS),
                            g(a("Risparmio dati"), a("Dati solo per alcune app")),
                            gt("Mobile", a("Utilizzo dati mobili"), a("Ciclo di fatturazione e avviso dati")),
                            gt("Wi-Fi", a("Utilizzo dati Wi-Fi"), a("Reti a consumo"))),
                      m("Hotspot mobile e tethering", az(TETHER, "com.android.settings/com.android.settings.TetherSettings", WIRELESS),
                            g(a("Hotspot mobile"), a("Tethering Bluetooth"), a("Tethering USB"), a("Tethering Ethernet")))),
                    g(m("Altre impostazioni di connessione", az(WIRELESS),
                            g(a("Ricerca dispositivi vicini"), a("Stampa", STAMPA), a("VPN", VPN),
                              a("DNS privato"), a("Ethernet"), a("Accelerazione download"), a("Disconnessione Wi-Fi automatica")))),
                    g(a("Impostazioni IP Wi-Fi", WIFI_IP, WIFI))),

                M("⧉" + T, 0xFF0A84FF, "Dispositivi connessi", "Quick Share • Android Auto", az(BT),
                    g(a("Quick Share", "app:com.samsung.android.app.sharelive"),
                      a("Cambio automatico Buds"),
                      a("Chiamate e messaggi su altri dispositivi"),
                      a("Continua le app su altri dispositivi"),
                      a("Multi Control"),
                      a("Collegamento a Windows", "app:com.microsoft.appmanager")),
                    g(a("Smart View", CAST), a("Galaxy Wearable", "app:com.samsung.android.app.watchmanager"),
                      a("SmartThings", "app:com.samsung.android.oneconnect"),
                      a("Android Auto", "app:com.google.android.projection.gearhead"),
                      a("Samsung DeX"))),

                M("◷" + T, 0xFF34C759, "Modalità e Routine", "Modalità • Routine",
                    az("app:com.samsung.android.app.routines"),
                    gt("Modalità", a("Sonno"), a("Teatro"), a("Lavoro"), a("Guida"), a("Allenamento"), a("Relax"),
                       a("Aggiungi modalità")),
                    gt("Routine", a("Le mie routine"), a("Scopri routine"), a("Aggiungi routine")))
            ),

            g(
                M("♪" + T, 0xFFFF2D55, "Suoni e vibrazione", "Modalità suono • Suoneria", az(SUONI),
                    g(scelta("Modalità suono", "modalita_suono",
                            new String[]{"Suono", "Vibrazione", "Silenzioso"}, new int[]{2, 1, 0}),
                      a("Vibrazione durante squillo"), a("Vibrazione durante modalità Silenzioso")),
                    g(a("Suoneria", SUONI), a("Suono notifiche"), a("Suono di sistema")),
                    gt("Volume", cursore("Suoneria", "vol_suoneria"), cursore("Notifiche", "vol_notifiche"),
                       cursore("Contenuti multimediali", "vol_media"), cursore("Sistema", "vol_sistema"),
                       cursore("Sveglia", "vol_sveglia"),
                       a("Usa tasti Volume per i contenuti multimediali")),
                    g(a("Modello di vibrazione chiamata"), a("Modello di vibrazione notifica"),
                      a("Intensità vibrazione"), a("Feedback a vibrazione")),
                    gt("Controllo suono e vibrazione di sistema",
                       interruttore("Tocchi", "suoni_tocco"),
                       interruttore("Vibrazione al tocco", "vibrazione_tocco"),
                       interruttore("Toni tastiera di composizione", "toni_tastiera"),
                       a("Schermata di blocco/sblocco"), a("Ricarica"), a("Tastiera Samsung")),
                    g(a("Qualità ed effetti audio"), a("Audio app separato"))),

                M("●" + T, 0xFFFF3B30, "Notifiche", "Barra di stato • Non disturbare", az(NOTIF2, NOTIF),
                    g(a("Notifiche app", NOTIF, NOTIF2), a("Notifiche schermata di blocco"),
                      a("Stile pop-up notifiche")),
                    gt("Non disturbare", interruttore("Non disturbare", "non_disturbare"),
                       a("Pianificazioni ed eccezioni", ZEN)),
                    g(m("Impostazioni avanzate", az(NOTIF2),
                        g(a("Mostra icone notifiche"), a("Mostra percentuale batteria"),
                          a("Indicatori icone app"), a("Promemoria notifiche"),
                          a("Notifiche flash", ACCESSIBILITA)),
                        g(a("Cronologia notifiche", STORIA_NOTIF, NOTIF2),
                          a("Conversazioni"), a("Bolle fluttuanti"),
                          a("Azioni e risposte suggerite", ASSIST_NOTIF, NOTIF2),
                          a("Mostra pulsante snooze"), a("Categorie notifiche app")),
                        g(a("Accesso alle notifiche del dispositivo", LISTENER),
                          a("Avvisi di emergenza wireless"))))),

                M("☀" + T, 0xFF007AFF, "Schermo", "Luminosità • Comfort visivo • Barra di navigazione", az(SCHERMO),
                    gt("Modalità", a("Chiaro", SCURO, SCHERMO), a("Scuro", SCURO, SCHERMO),
                       a("Impostazioni modalità Scuro", SCURO, SCHERMO)),
                    gt("Luminosità", cursore("Luminosità", "luminosita"),
                       interruttore("Luminosità adattiva", "luminosita_auto"),
                       a("Luminosità extra")),
                    g(a("Fluidità movimento"), a("Comfort visivo", NOTTE, SCHERMO), a("Modalità schermo")),
                    g(a("Dimensione e stile carattere", TESTO, SCHERMO), a("Zoom schermo"),
                      a("Risoluzione schermo"), a("App a schermo intero"), a("Inserimento fotocamera")),
                    g(scelta("Timeout schermo", "timeout",
                            new String[]{"15 secondi", "30 secondi", "1 minuto", "2 minuti", "5 minuti", "10 minuti"},
                            new int[]{15000, 30000, 60000, 120000, 300000, 600000}),
                      interruttore("Rotazione automatica", "rotazione")),
                    g(a("Modalità Facile"), a("Pannelli Edge"), a("Barra di navigazione"),
                      a("Protezione da tocco accidentale"), a("Sensibilità al tocco"),
                      a("Mostra informazioni di ricarica"), a("Salvaschermo", SALVASCHERMO, SCHERMO))),

                M("⚡" + T, 0xFF34C759, "Batteria", "Risparmio energetico • Ricarica", az(BATTERIA, DEVICE_CARE),
                    g(a("Utilizzo batteria", BATTERIA)),
                    g(a("Risparmio energetico", RISPARMIO, BATTERIA), a("Limiti utilizzo in background"),
                      a("Ottimizzazione batteria app", OTTIM)),
                    g(a("Protezione batteria"), m("Impostazioni di ricarica", az(BATTERIA),
                        g(a("Ricarica super rapida"), a("Ricarica rapida"), a("Ricarica wireless rapida"),
                          a("Ricarica wireless inversa")))),
                    g(m("Altre impostazioni batteria", az(BATTERIA),
                        g(a("Batteria adattiva"), a("Mostra percentuale batteria"), a("Informazioni batteria"))))),

                M("✿" + T, 0xFF32ADE6, "Sfondo e stile", "Sfondi • Tavolozza colori", az(SFONDO, SCHERMO),
                    g(a("Cambia sfondi", SFONDO), a("Tavolozza colori"), a("Applica colore alle icone app")),
                    g(a("Servizi sfondi"), a("Sfondi creativi"), a("Sfondi con effetto"))),

                L("◐" + T, 0xFFAF52DE, "Temi", "Temi • Sfondi • Icone",
                    "app:com.samsung.android.themestore", SFONDO),

                M("⌂" + T, 0xFF5856D6, "Schermata Home", "Layout • Griglia app • Cartelle",
                    az("com.sec.android.app.launcher/com.android.homescreen.settings.HomeScreenSettingsActivity",
                       "com.sec.android.app.launcher/com.android.launcher3.settings.SettingsActivity", HOME),
                    g(a("Layout schermata Home"), a("Griglia schermata Home"), a("Griglia schermata app"),
                      a("Griglia cartelle")),
                    g(a("Aggiungi nuove app alla schermata Home"), a("Blocca layout schermata Home"),
                      a("Mostra pulsante schermata App"), a("Scorri giù per il pannello notifiche"),
                      a("Ruota in orizzontale"), a("Nascondi app su schermate Home e App"),
                      a("Indicatori icone app"), a("Mostra suggerimenti app"), a("Avvio app predefinito", HOME))),

                M("⊙" + T, 0xFF5856D6, "Schermata di blocco e AOD", "Tipo blocco schermo • Always On Display",
                    az(SICUREZZA),
                    g(a("Tipo di blocco schermo", BLOCCO, SICUREZZA), a("Smart Lock"),
                      a("Impostazioni blocco protetto")),
                    g(a("Always On Display"), a("Modifica schermata di blocco"), a("Widget")),
                    g(a("Notifiche"), a("Collegamenti"), a("Orologio roaming"),
                      a("Informazioni di contatto"), a("Servizi schermata di blocco"),
                      a("Tocca e tieni premuto per modificare")))
            ),

            g(
                M("⚑" + T, 0xFF007AFF, "Sicurezza e privacy", "Biometria • Autorizzazioni", az(SICUREZZA, SICUREZZA_CENTRO),
                    g(a("Stato sicurezza e privacy", SICUREZZA_CENTRO, SICUREZZA)),
                    g(m("Blocco schermo e biometria", az(SICUREZZA),
                        g(a("Tipo di blocco schermo", BLOCCO, SICUREZZA), a("Riconoscimento viso", BIOMETRIA, SICUREZZA),
                          a("Impronte digitali", BIOMETRIA, SICUREZZA), a("Altre impostazioni biometria")))),
                    g(a("Account Samsung", "app:com.osp.app.signin", ACCOUNT),
                      a("Trova dispositivo", "app:com.samsung.android.fmm"),
                      a("Protezione app (Google Play Protect)"),
                      a("Aggiornamenti", AGGIORNA, SICUREZZA)),
                    gt("Privacy", a("Autorizzazioni usate nelle ultime 24 ore", USO_PERMESSI, PRIVACY),
                       a("Gestione autorizzazioni", PERMESSI, PRIVACY), a("Altre impostazioni privacy", PRIVACY)),
                    g(a("Cartella protetta", "app:com.samsung.knox.securefolder"),
                      a("Samsung Pass", "app:com.samsung.android.samsungpass"),
                      a("Wi-Fi sicuro"), a("Blocco automatico"), a("Protezione dispositivo smarrito"),
                      a("Samsung Blockchain Keystore")),
                    g(m("Altre impostazioni di sicurezza", az(SICUREZZA),
                        g(a("App di amministrazione dispositivo", AMMINISTRATORI, SICUREZZA),
                          a("Archiviazione credenziali"), a("Blocco app sullo schermo"),
                          a("Accesso ai dati di utilizzo", UTILIZZO),
                          a("Installa app sconosciute", SCONOSCIUTE),
                          a("Accesso alle notifiche", LISTENER),
                          a("Agenti di attendibilità"), a("Avviso di sicurezza SIM"))))),

                M("➤" + T, 0xFF007AFF, "Posizione", "Richieste posizione app", az(POSIZIONE),
                    g(a("Usa posizione", POSIZIONE)),
                    g(a("Autorizzazioni app", PERMESSI, POSIZIONE), a("Richieste di posizione recenti")),
                    g(a("Servizi di posizione"), a("Accuratezza posizione Google"),
                      a("Cronologia delle posizioni Google"), a("Servizio di localizzazione di emergenza"))),

                M("✚" + T, 0xFFFF3B30, "Sicurezza ed emergenza", "Informazioni mediche • Avvisi di emergenza",
                    az(EMERGENZA, SICUREZZA_CENTRO, PRINCIPALE),
                    g(a("Informazioni mediche", EMERGENZA), a("Contatti di emergenza", EMERGENZA)),
                    g(a("SOS emergenze"), a("Condivisione posizione di emergenza"),
                      a("Avvisi di emergenza wireless"), a("Avvisi terremoti"),
                      a("Modalità di emergenza"), a("Rilevamento incidente"))),

                M("☁" + T, 0xFF32ADE6, "Account e backup", "Gestione account • Smart Switch", az(ACCOUNT),
                    g(a("Gestione account", ACCOUNT), a("Aggiungi account", ADD_ACCOUNT)),
                    gt("Samsung Cloud", a("Backup dati"), a("Ripristina dati"), a("Sincronizza")),
                    gt("Google Drive", a("Backup dei dati", ACCOUNT)),
                    g(a("Smart Switch", "app:com.sec.android.easyMover"),
                      a("Trasferimento dati su dispositivo esterno"))),

                L("G", 0xFF4285F4, "Google", "Servizi e preferenze", GOOGLE, GOOGLE2, ACCOUNT)
            ),

            g(
                M("✦" + T, 0xFFFF9500, "Funzioni avanzate", "Tasto laterale • Movimenti e gesti", az(PRINCIPALE),
                    g(a("Labs"), a("Tasto laterale")),
                    g(m("Movimenti e gesti", az(PRINCIPALE),
                        g(a("Solleva per riattivare"), a("Doppio tocco per accendere schermo"),
                          a("Doppio tocco per spegnere schermo"), a("Mantieni schermo acceso durante la visione"),
                          a("Avviso quando si solleva il telefono"), a("Silenziamento con i gesti"),
                          a("Scorri con il palmo per screenshot"))),
                      a("Modalità una mano")),
                    g(a("Bixby", "app:com.samsung.android.bixby.agent"), a("Finestre multiple"),
                      a("Screenshot e registrazione schermo"), a("Mostra contatti quando condividi contenuti"),
                      a("Effetti videochiamata"), a("Luminosità video"), a("Dual Messenger"),
                      a("Controller giochi"), a("S Pen (solo S25 Ultra)"))),

                M("✧" + T, 0xFF7B61FF, "Galaxy AI", "Assistente chiamate • Assistente note", az(PRINCIPALE),
                    g(a("Now Brief"), a("Now Bar"), a("Cerchia e cerca con Google")),
                    gt("Comunicazione", a("Assistente chiamate"), a("Interprete"),
                       a("Traduzione live"), a("Assistente chat"), a("Assistente scrittura")),
                    gt("Produttività", a("Assistente note"), a("Assistente browsing"),
                       a("Assistente trascrizioni"), a("Assistente schizzi")),
                    gt("Creatività", a("Assistente foto"), a("Editor foto"), a("Audio Eraser"),
                       a("Creatore ritratti"), a("Assistente disegno")),
                    g(a("Elabora i dati solo sul dispositivo"))),

                M("◔" + T, 0xFF30B0C7, "Benessere digitale e controllo genitori", "Tempo di utilizzo • Timer app",
                    az("app:com.samsung.android.forest", PRINCIPALE),
                    g(a("Dashboard"), a("Obiettivi tempo di utilizzo"), a("Timer app")),
                    g(a("Modalità guida"), a("Monitoraggio del volume"), a("Ora di andare a dormire")),
                    g(a("Controllo genitori"))),

                M("⟳" + T, 0xFF30B0C7, "Assistenza dispositivo", "Archiviazione • Memoria • Protezione app",
                    az(DEVICE_CARE, BATTERIA),
                    g(a("Ottimizza ora"), a("Prestazioni"), a("Batteria", BATTERIA, DEVICE_CARE),
                      a("Archiviazione", ARCHIVIO, DEVICE_CARE), a("Memoria")),
                    g(a("Protezione app"), a("Ottimizzazione automatica"), a("Riavvio automatico"),
                      a("Diagnostica"), a("Aggiornamento software", AGGIORNA))),

                M("▦" + T, 0xFF5856D6, "App", "App predefinite • Impostazioni app", az(APP, TUTTE_APP),
                    g(a("Scegli app predefinite", PREDEF, APP), a("Impostazioni app Samsung", APP)),
                    g(a("Tutte le app", TUTTE_APP, APP)),
                    g(m("Accesso speciale", az(APP),
                        g(a("Mostra sopra altre app", SOPRA), a("Modifica impostazioni di sistema", SCRIVI),
                          a("Installa app sconosciute", SCONOSCIUTE), a("Accesso ai dati di utilizzo", UTILIZZO),
                          a("Accesso Non disturbare", ACCESSO_ZEN), a("Accesso a tutti i file", FILE_TUTTI),
                          a("Ottimizza utilizzo batteria", OTTIM), a("Accesso alle notifiche", LISTENER),
                          a("Sveglie e promemoria"), a("Picture-in-picture"), a("Implementazione WebView", WEBVIEW))))),

                M("⚙" + T, 0xFF8E8E93, "Gestione generale", "Lingua e tastiera • Data e ora • Ripristina",
                    az(LINGUA, PRINCIPALE),
                    g(a("Lingua", LINGUA), a("Lingue app", LINGUA), a("Sintesi vocale", VOCE_TTS, LINGUA)),
                    g(a("Data e ora", DATA)),
                    g(a("Impostazioni Tastiera Samsung", TASTIERE), a("Elenco tastiere e predefinita", TASTIERE),
                      a("Tastiera fisica", TASTIERA_FISICA, TASTIERE), a("Mouse e trackpad", TASTIERA_FISICA),
                      a("Dizionario personale", DIZIONARIO, TASTIERE)),
                    g(a("Password, passkey e compilazione automatica", CREDENZIALI, AUTOFILL, SICUREZZA)),
                    g(a("Personalizzazione servizio"), a("Contattaci", "app:com.samsung.android.voc")),
                    g(m("Ripristina", az(PRINCIPALE),
                        g(a("Ripristina tutte le impostazioni"), a("Ripristina impostazioni di rete"),
                          a("Ripristina impostazioni accessibilità"), a("Ripristino dati di fabbrica")),
                        g(a("Riavvio automatico")))),
                    g(a("Spegnimento"))),

                M("☺" + T, 0xFF007AFF, "Accessibilità", "TalkBack • Miglioramenti visibilità", az(ACCESSIBILITA),
                    g(a("Consigliate per te"), a("TalkBack")),
                    g(a("Miglioramenti visibilità"), a("Miglioramenti udito"), a("Sottotitoli", SOTTOTITOLI, ACCESSIBILITA),
                      a("Interazione e destrezza"), a("Impostazioni avanzate")),
                    g(a("App installate"), a("Informazioni sull'accessibilità"), a("Contattaci"))),

                M("⇩" + T, 0xFF8E8E93, "Aggiornamento software", "Scarica e installa", az(AGGIORNA, SICUREZZA),
                    g(a("Scarica e installa"), a("Scaricamento automatico tramite Wi-Fi"),
                      a("Ultimo aggiornamento")),
                    g(a("Aggiornamento di sistema Google Play"))),

                L("?", 0xFFFF9500, "Suggerimenti e guida utente", "Funzioni utili • Guida utente",
                    "app:com.samsung.android.app.tips", PRINCIPALE),

                M("ⓘ" + T, 0xFF8E8E93, "Info sul telefono", "Stato • Informazioni legali • Nome telefono", az(INFO),
                    g(a("Modifica nome dispositivo"), a("Numero di telefono")),
                    g(a("Stato"), a("Informazioni legali", LEGALE, INFO), a("Informazioni software"),
                      a("Informazioni batteria"))),

                L("{}", 0xFF636366, "Opzioni sviluppatore", "Visibile solo se attivate", SVILUPPO, INFO)
            )
        );
        collega(radice);
        return radice;
    }

    static void collega(Voce v) {
        for (Gruppo gr : v.gruppi)
            for (Voce f : gr.voci) {
                f.padre = v;
                collega(f);
            }
    }
}
